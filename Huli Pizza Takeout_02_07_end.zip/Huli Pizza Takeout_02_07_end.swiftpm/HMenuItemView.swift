import SwiftUI

import SwiftUI
struct HMenuItemView: View {
    var item:MenuItem
    var isTitle = false
    var body: some View {
        HStack{
            Image(item.thumbnailName)
                .resizable()
                .scaledToFill()
                .frame(maxWidth:150,maxHeight: 150)
                .clipShape(Circle())
            VStack(alignment:.leading){
                RatingsView(rating: item.rating)
                Text(item.name)
                    .font(isTitle ? .title2 : .headline)
                if !isTitle {
                    Text(item.description)
                        .font(.caption)
                }
                Text(item.formattedPrice)
            }
            Spacer()
        }
    }
}

struct HMenuItemView_Previews: PreviewProvider {
    static var previews: some View {
        HMenuItemView(item: testMenuItem1)
    }
}

