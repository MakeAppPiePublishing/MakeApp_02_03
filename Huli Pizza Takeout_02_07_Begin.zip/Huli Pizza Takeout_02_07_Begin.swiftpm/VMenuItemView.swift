import SwiftUI

import SwiftUI
struct VMenuItemView: View {
    var item:MenuItem
    var isTitle = false
    var body: some View {
        VStack{
            Image(systemName: item.imageName)
                .resizable()
                .scaledToFit()
                .frame(maxWidth:150,maxHeight: 150)
                .clipShape(Circle())
            HStack{
                Text(item.name)
                    .font(isTitle ? .title2 : .headline)
                if !isTitle {
                    Text("Menu Description")
                        .font(.caption)
                }
                Text(item.formattedPrice)
            }
            Spacer()
        }
    }
}

struct VMenuItemView_Previews: PreviewProvider {
    static var previews: some View {
        VMenuItemView(item: testMenuItem1)
    }
}
