import SwiftUI
struct MenuItemView: View {
    var item:MenuItem
    var isTitle = false
    var isVertical = false
    var body: some View {
        if isVertical{
            VMenuItemView(item: item, isTitle: isTitle)
        } else {
            HMenuItemView(item: item, isTitle: isTitle)
        }
    }
}

struct MenuItemView_Previews: PreviewProvider {
    static var previews: some View {
        MenuItemView(item: testMenuItem1)
    }
}
