import SwiftUI

struct RatingsView: View {
    var rating:Int = 5
    var body: some View {
        HStack{ 
            ForEach(0..<rating,id:\.self){ star in 
                Image(systemName: "star")
                    .font(.caption2)
            }
        }
    }
}

struct RatingsView_Previews: PreviewProvider {
    static var previews: some View {
        RatingsView()
    }
}
